---
weight: 3000
title: "Functionalities"
description: "Descriptions and examples of the theme functionalities."
titleIcon: "fa-solid fa-cubes"
categories: ["Functionalities"]
tags: ["Content management"]
---

---

{{< treeview
  display="tree"
/>}}
