---
weight: 13000
title: "Banner"
description: "How to manage banner?"
titleIcon: "fa-solid fa-bullhorn"
categories: ["Functionalities"]
tags: ["Content management"]
---

# Description
---

In the theme, it is possible to display a banner, on top of the page content, using two available options:
* [activate the whole website as an archived one, and print a banner on all pages](global/)
* [activate a banner for a single page](single/)
