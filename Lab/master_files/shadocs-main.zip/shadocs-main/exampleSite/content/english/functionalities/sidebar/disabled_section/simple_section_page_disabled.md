---
weight: 1000
title: "Simple disabled section page"
description: "Sidebar: Simple disabled section page"
categories: ["Functionalities"]
---

# Description
---

Cf. [Simple page](../simple_page/)