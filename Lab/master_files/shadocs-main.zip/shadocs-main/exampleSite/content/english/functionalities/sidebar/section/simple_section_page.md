---
weight: 1000
title: "Simple section page"
description: "Sidebar: Simple section page"
categories: ["Functionalities"]
---

# Description
---

Cf. [Simple page](../simple_page/)