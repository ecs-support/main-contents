---
weight: 1000
title: "Disabled simple page"
description: "Sidebar: Disabled simple page"
categories: ["Functionalities"]
sidebarDisabled: true
---

# Manually disabled simple page
---
