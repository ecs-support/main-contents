---
weight: 2000
title: "Simple page 2"
description: "Sidebar: Simple page 2"
categories: ["Functionalities"]
---
