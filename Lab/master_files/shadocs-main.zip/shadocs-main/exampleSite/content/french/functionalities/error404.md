---
weight: 11000
title: "404"
description: "Comment gérér la page 404 ?"
titleIcon: "fa-solid fa-circle-xmark"
categories: ["Fonctionnalités"]
---

# Description
---

Par défaut une page d'erreur 404 est fournie par le thème, mais il est possible d'en définir une spécifique en suivant la [documentation Hugo](https://gohugo.io/templates/404/).

# Page 404 du thème
---

* [404](/404.html)
