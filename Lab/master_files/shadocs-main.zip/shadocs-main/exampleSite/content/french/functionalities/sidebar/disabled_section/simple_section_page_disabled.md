---
weight: 1000
title: "Page simple de section désactivée"
description: "Menu latéral: Page simple de section désactivée"
categories: ["Fonctionnalités"]
---

# Description
---

Cf. [Page simple](../simple_page/)