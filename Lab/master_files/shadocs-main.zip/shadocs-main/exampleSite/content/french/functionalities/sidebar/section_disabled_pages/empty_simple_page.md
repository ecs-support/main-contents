---
weight: 2000
title: "Page simple vide"
description: "Menu latéral: Page simple vide"
categories: ["Fonctionnalités"]
---
