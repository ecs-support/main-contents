---
title: "{{< pagebreak >}}"
description: "Shortcode {{< pagebreak >}}."
categories: ["Shortcode"]
tags: ["Gestion du contenu"]
---

# Description
---

Le shortcode **pagebreak** permet de définir un saut de page pour l'impression.

# Paramètres
---

| Nom | Type(nommé/positionnel) | Description |
| --- | ----------------------- | ----------- |

{{< pagebreak >}}
# Exemples
---

| Markdown | Rendu |
| -------- | ----- |
|{{< md >}}
```
{{</*/* pagebreak */*/>}}
# Exemples
```
{{< /md >}}| (***Rendu non disponible et visible uniquement dans l'aperçu impression***) |
