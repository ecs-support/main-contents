module.exports = {
    engines: {
        "@bookshop/hugo-engine": {}
    }
}
