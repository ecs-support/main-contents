---
title: "Home"
slider:
  preheading: "Prepare for new future"
  heading: "Our work is <br>presentation of our <br>capabilities."
  background_image: "/images/bg/home-1.jpg"
  link:
    text: "Get started"
    url: "#"

intro:
  preheading: "We are creative & expert people"
  heading: "We work with business & provide solution to client with their business problem"
  sections:
    - icon: "ti-desktop"
      heading: "Modern & Responsive design"
      text: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Odit, ducimus."
    - icon: "ti-medall"
      heading: "Awarded licensed company"
      text: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Odit, ducimus."
    - icon: "ti-layers"
      heading: "Build your website Professionally"
      text: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Odit, ducimus."
---